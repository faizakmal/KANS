# KANS
Fungsi File :
1. Controller : Fungsi Folder Include yang dulu
2. Dist : Buat CSS dan JS
3. View : File HTML
4. Database : File Database
