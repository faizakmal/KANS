<?php

$dbServername = "mysql.hostinger.co.id";
$dbUsername   = "u887437477_kans";
$dbPassword   = "123123123";
$dbName       = "u887437477_kans";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
